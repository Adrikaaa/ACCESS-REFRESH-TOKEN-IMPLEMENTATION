import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./app/App.jsx";

createRoot(document.getElementById("root")).render(<App />);
